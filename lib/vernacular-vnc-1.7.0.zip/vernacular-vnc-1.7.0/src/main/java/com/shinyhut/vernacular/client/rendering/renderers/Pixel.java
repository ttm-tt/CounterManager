package com.shinyhut.vernacular.client.rendering.renderers;

public class Pixel {

    private final int red;
    private final int green;
    private final int blue;

    public Pixel(int red, int green, int blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    public int getRed() {
        return red;
    }

    public int getGreen() {
        return green;
    }

    public int getBlue() {
        return blue;
    }
}
